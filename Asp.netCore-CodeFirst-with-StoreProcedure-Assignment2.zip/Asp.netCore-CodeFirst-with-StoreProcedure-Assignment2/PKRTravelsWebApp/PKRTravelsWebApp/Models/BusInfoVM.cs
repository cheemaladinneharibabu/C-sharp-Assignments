﻿namespace PKRTravelsWebApp.Models
{
    public class BusInfoVM
    {
        public BusInfo busInfo { get; set; }
        public List<BusInfo> BusInfoList { get; set; }
    }
}
